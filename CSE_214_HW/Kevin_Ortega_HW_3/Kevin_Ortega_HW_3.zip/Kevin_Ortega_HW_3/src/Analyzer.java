import java.util.Scanner;
public class Analyzer
{
    static Scanner input = new Scanner(System.in);

    public static void main(String[] args) throws IllegalArgumentException
    {
        double probability;
        int maxFloor;
        int totalElev;
        int simulationLength;

        System.out.println();
    }
}
