public class Simulator
{
    public static void Simulator(double probability,int numOfFloors,int numOfElevators, int simulationLength)
    {


    }
}
